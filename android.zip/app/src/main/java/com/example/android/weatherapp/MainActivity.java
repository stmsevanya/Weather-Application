package com.example.android.weatherapp;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {


    class WeatherInfo extends AsyncTask<String, Void, String>{
        @Override
        protected String doInBackground(String... strings) {

            try {
                URL url = new URL(strings[0]);
                HttpURLConnection connection = (HttpURLConnection)url.openConnection();
                connection.connect();

                InputStream is = (InputStream)connection.getInputStream();
                InputStreamReader reader = new InputStreamReader(is);

                int data = reader.read();
                String appDetails="";
                char current;

                while(data!=-1)
                {
                    current=(char)data;
                    appDetails += current;

                    data= reader.read();
                }

                return appDetails;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    public void getWeatherInfo(View view){

        EditText cityName= (EditText)findViewById(R.id.cityEditText);
        Button viewWeather=(Button)findViewById(R.id.viewWeatherButton);
        TextView weatherTextView = (TextView)findViewById(R.id.weatherTextView);

        WeatherInfo weatherInfo = new WeatherInfo();
        try {

            if(cityName.getText().toString().isEmpty())
            {
                Toast.makeText(this,"Please enter city name",Toast.LENGTH_SHORT).show();
                weatherTextView.setText("");
            }
            else {

                String weatherAppDetails = weatherInfo.execute("http://samples.openweathermap.org/data/2.5/weather?q=" + cityName.getText().toString() + "&apikey=9b74f20bdc0c66c90f06cfb6b7386e6d").get();
                Log.i("onCreate", weatherAppDetails);

                JSONObject jsonObject = new JSONObject(weatherAppDetails);
                String weather = jsonObject.getString("weather");

                JSONArray jsonArray = new JSONArray(weather);

                String main = "";
                String description = "";

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject arrayObject = jsonArray.getJSONObject(i);

                    main = arrayObject.getString("main");
                    description = arrayObject.getString("description");
                }

                weatherTextView.setText("Main\n" + main + "\n\n"
                        + "Description\n" + description);

                Log.i("main", main);
                Log.i("description", description);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




    }
}
